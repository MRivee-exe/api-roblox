﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;

#nullable disable
namespace ForlornApi
{
  public class Forlorn
  {
    public static string ForlornVersion = "1.0.6";
    private bool isInjected;
    private System.Timers.Timer time;
    private bool autoinject;

    [DllImport("ForlornInject.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern void StartClient();

    [DllImport("ForlornInject.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    private static extern void ExecuteSC(byte[] scriptSource);

    [DllImport("ForlornInject.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    private static extern IntPtr ScriptCompilable(byte[] scriptSource);

    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern bool FreeLibrary(IntPtr hModule);

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    public static extern IntPtr GetModuleHandle(string lpModuleName);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr LoadLibrary(string lpFileName);

    public Forlorn()
    {
      this.time = new System.Timers.Timer();
      this.time.Elapsed += new ElapsedEventHandler(this.timertick);
      this.time.AutoReset = true;
      Task.Run((Func<Task>) (async () =>
      {
        while (true)
        {
          if (this.IsRobloxOpen() && this.autoinject && !this.isInjected)
            this.InjectForlorn();
          await Task.Delay(1000);
        }
      }));
    }

    public void KillRoblox()
    {
      if (!this.IsRobloxOpen())
        return;
      foreach (Process process in Process.GetProcessesByName("RobloxPlayerBeta"))
        process.Kill();
    }

    public void AutoInject(bool value) => this.autoinject = value;

    public bool IsInjected() => this.isInjected;

    public bool IsRobloxOpen() => Process.GetProcessesByName("RobloxPlayerBeta").Length != 0;

    public void InjectForlorn()
    {
      if (!this.IsRobloxOpen())
        return;
      try
      {
        Forlorn.StartClient();
        if (!this.time.Enabled)
          this.time.Start();
        this.isInjected = true;
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show("Failed to attach ForlornApi: " + ex.Message, "Attaching Error");
        this.isInjected = false;
      }
    }

    public void Deject()
    {
      this.isInjected = false;
      IntPtr moduleHandle = Forlorn.GetModuleHandle("ForlornInject.dll");
      if (moduleHandle != IntPtr.Zero)
        Forlorn.FreeLibrary(moduleHandle);
      this.Reload();
    }

    public void Reload()
    {
      if (this.isInjected)
        return;
      Forlorn.LoadLibrary("ForlornInject.dll");
      this.isInjected = true;
    }

    private void timertick(object sender, EventArgs e)
    {
      if (this.IsRobloxOpen())
        return;
      this.isInjected = false;
      if (this.time.Enabled)
        this.time.Stop();
    }

    public void ExecuteScript(string script)
    {
      try
      {
        if (!this.IsInjected() || !this.IsRobloxOpen())
          return;
        Forlorn.ExecuteSC(Encoding.UTF8.GetBytes(script));
      }
      catch (Exception ex)
      {
        Console.WriteLine("Error executing script: " + ex.Message);
      }
    }

    private struct ClientInfo
    {
      public string version;
      public string name;
      public int id;
    }
  }
}
