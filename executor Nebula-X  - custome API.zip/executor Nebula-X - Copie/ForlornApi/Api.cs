﻿// Decompiled with JetBrains decompiler
// Type: ForlornApi.Api
// Assembly: ForlornApi, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: BEE778A0-7431-4997-B00F-9A4099D7F6DD
// Assembly location: C:\Users\Solal\Desktop\executor Nebula-X\ForlornApi.dll

using System;
using System.Diagnostics;
using System.Windows.Forms;

#nullable disable
namespace ForlornApi
{
  public static class Api
  {
    private static Timer time1 = new Timer();
    private static Forlorn forlorn;

    static Api()
    {
      Api.CreateForlorn();
      Api.time1.Tick += new EventHandler(Api.ticktimer32433);
      Api.time1.Start();
    }

    private static void CreateForlorn() => Api.forlorn = new Forlorn();

    public static void Inject() => Api.forlorn?.InjectForlorn();

    public static void KillRoblox() => Api.forlorn?.KillRoblox();

    public static bool IsInjected()
    {
      Forlorn forlorn = Api.forlorn;
      return forlorn != null && forlorn.IsInjected();
    }

    public static bool IsRobloxOpen() => Process.GetProcessesByName("RobloxPlayerBeta").Length != 0;

    public static void ExecuteScript(string script) => Api.forlorn?.ExecuteScript(script);

    private static void ticktimer32433(object sender, EventArgs e)
    {
      if (!Api.IsRobloxOpen())
      {
        if (Api.forlorn == null)
          return;
        Api.forlorn.Deject();
        Api.forlorn = (Forlorn) null;
      }
      else
      {
        if (Api.forlorn != null)
          return;
        Api.CreateForlorn();
      }
    }

    public static void SetAutoInject(bool value) => Api.forlorn?.AutoInject(value);
  }
}
