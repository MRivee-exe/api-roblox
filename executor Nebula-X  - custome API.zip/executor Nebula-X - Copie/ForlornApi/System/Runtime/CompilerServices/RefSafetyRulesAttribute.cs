﻿// Decompiled with JetBrains decompiler
// Type: System.Runtime.CompilerServices.RefSafetyRulesAttribute
// Assembly: ForlornApi, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: BEE778A0-7431-4997-B00F-9A4099D7F6DD
// Assembly location: C:\Users\Solal\Desktop\executor Nebula-X\ForlornApi.dll

using System;
using System.Diagnostics.CodeAnalysis;  // Corrected namespace
using System.Runtime.InteropServices;

#nullable disable

namespace System.Runtime.CompilerServices
{
    [CompilerGenerated]
    [Embedded]  
    [AttributeUsage(AttributeTargets.Module, AllowMultiple = false, Inherited = false)]
    internal sealed class RefSafetyRulesAttribute : Attribute
    {
        public readonly int Version;

        public RefSafetyRulesAttribute([In] int obj0) => this.Version = obj0;
    }

    
    [AttributeUsage(AttributeTargets.All)]
    internal sealed class EmbeddedAttribute : Attribute
    {
    }
}
